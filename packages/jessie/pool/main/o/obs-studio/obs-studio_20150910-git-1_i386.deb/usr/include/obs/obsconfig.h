
#pragma once

#define OBS_VERSION "0.11.4-43-gb2714fa"
#define OBS_DATA_PATH "share/obs"
#define OBS_INSTALL_PREFIX "/usr/"
#define OBS_PLUGIN_DESTINATION "lib/obs-plugins"
#define OBS_RELATIVE_PREFIX "../"
#define OBS_UNIX_STRUCTURE 1
